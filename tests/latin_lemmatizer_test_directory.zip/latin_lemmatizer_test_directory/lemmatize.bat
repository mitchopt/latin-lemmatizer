uv run --with ../_repos/Latin-Lemmatizer latin_lemmatizer ^
--input-parameters ./input_parameters.yaml