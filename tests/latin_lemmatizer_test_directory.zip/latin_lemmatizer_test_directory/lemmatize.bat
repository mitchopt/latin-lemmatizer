uv run latin_lemmatizer ^
--input-parameters ./input_parameters.yaml